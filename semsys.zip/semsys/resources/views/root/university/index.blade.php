@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/home">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Universidades</li>
              </ol>
            </nav>

            <div class="card">
                <div class="card-header">{{ __('UNIVERSIDADES') }}</div>
                <input type="text" name="buscar" id="buscar-uni" placeholder="BUSCAR">
                <div class="card-body">

                    @if (session('status'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>{{ session('status') }}</strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Teléfono</th>
                                <th scope="col">Email</th>
                                <th scope="col">Detalles</th>
                                <th scope="col">Admin</th>
                            </tr>
                        </thead>
                        <tbody id="tabla-uni">
                            
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
    <script type="text/javascript">
        $(document).ready(function (){

             var datos; 
            $("#tabla-uni").html('<tr><td colspan="8"><div class="d-flex justify-content-center"> <div class="spinner-border" role="status"> <span class="sr-only">Loading...</span> </div> </div></td></tr>');
            $.getJSON('https://semsys.sev.gob.mx/ApiGlobal/ApiGeneral/aievac/GetAllSubsTecno', function(data){
                datos=data;
                $("#tabla-uni").html('');
                for(var i=0;i<data.length;i++){
                    
                    $("#tabla-uni").append("<tr><td>"+(i+1)+"</td><td>"+data[i].Nombre+"</td><td>"+data[i].NoTelefono+"</td><td>"+data[i].Correo+"</td><td><a class='btn btn-primary' href='#' role='button'>Detalles</a></td><td><a class='btn btn-primary' href='/root/university/encargado/"+data[i].Id_Subsistema+"' role='button'>Asignar</a></td></tr>");
                        
                }
            });

            $("#buscar-uni").keyup(function(){
                _this = this;
                 // Show only matching TR, hide rest of them
                 $.each($("#tabla-uni tr"), function() {
                 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
                 $(this).hide();
                 else
                 $(this).show();
                 });
                 });
            });
    </script>
@endsection

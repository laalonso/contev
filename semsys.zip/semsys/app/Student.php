<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $fillable = [
         'enrollment','personal_email', 'cv', 'status', 'programa_id','user_id','university_id','subsistema_id'
    ];

    public function evaluations()
    {
        return $this->hasMany('App\Evaluation');
    }

    public function programs()
    {
        return $this->belongsToMany('App\Program', 'program_students', 'student_id','program_id')->withTimestamps();
    }

    public function projects()
    {
        return $this->belongsToMany('App\Project', 'project_students', 'student_id', 'project_id')->withTimestamps();
    }
    public function user(){
        return $this->belongsTo('App\User');
    }

}

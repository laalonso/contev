<?php

namespace App\Http\Controllers\Root;

use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\University;
use App\Program;
use App\Student;
use App\ProgramStudent;
use App\User;
use Auth;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $id_universidad=Auth::user()->university()->first()->university_id;

        $estudiantes= Student::all()->where('subsistema_id',$id_universidad);

        return view('root.university.student.index',['estudiantes'=>$estudiantes]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('root.university.student.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|max:60|string',
            'apellido_paterno' => 'required|max:45|string',
            'apellido_materno' => 'required|max:45|string',
            'telefono' => 'required|max:20',
            'email_escolar' => 'required|string|email|max:100',
            'estatus' => 'required|max:50|string',
            'imagen' => 'required|max:1000',
        ]);

        $file = $request->file('imagen')->store('student');

        $usernew=new User;
            $usernew->name=$request->nombre;
            $usernew->f_surname=$request->apellido_paterno;
            $usernew->s_surname=$request->apellido_materno;
            $usernew->email=$request->email_escolar;
            $usernew->phone=$request->telefono;
            $usernew->password=bcrypt($request->password);
            $usernew->image=$file;
            $usernew->role_id=3;
        $usernew->save();

        $user_id=User::all()->where('email',$request->email_escolar)->first()->id;

        $id_universidad=Auth::user()->university()->first()->university_id;

        $studentnew = new Student;
            $studentnew->enrollment = $request->enrollment;
            $studentnew->personal_email ="";
            $studentnew->cv ="";
            $studentnew->status =$request->estatus;
            $studentnew->program_id =$request->programa;
            $studentnew->user_id=$user_id;
            $studentnew->university_id=$request->unidad;
            $studentnew->subsistema_id=$id_universidad;
        $studentnew->save();

        return redirect()->action('Root\StudentController@index')->with('status', 'Estudiante creado exitosamente');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $student = decrypt($id);
        $all = Program::all();
        $all2 = Student::find($student);

        $all3 = DB::table('program_students')
        ->select('programs.*','universities.name as name1','systems.name as name2','modalities.name as name3')
        ->leftJoin('programs','program_students.program_id','=','programs.id')
        ->leftJoin('universities','programs.university_id','=','universities.id')
        ->leftJoin('modalities','programs.modality_id','=','modalities.id')
        ->leftJoin('systems','programs.system_id','=','systems.id')
        ->where('student_id',$student)
        ->get();
        return view('root.university.student.edit',['all'=>$all, 'info'=>$all2, 'all3'=>$all3]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $student = decrypt($id);

        $request->validate([
            'nombre' => 'required|max:60|string',
            'apellido_paterno' => 'required|max:45|string',
            'apellido_materno' => 'required|max:45|string',
            'telefono' => 'required|max:20',
            'email_escolar' => 'required|string|email|max:100|unique:students,school_email,'.$student,
            'email_personal' => 'required|string|email|max:100|unique:students,personal_email,'.$student,
            'estatus' => 'required|max:50|string',
            'cv' => 'nullable|mimes:pdf|max:10000',
            'imagen' => 'nullable|max:1000',
        ]);

        $data = $request->all();
        $insert = array();

        foreach($data['programa'] as $key => $rating) {
            $insert[$key]['programa'] = $rating;
        }

        foreach ($insert as $key2) {
            Validator::make($key2, [
                'programa' => 'required|numeric|digits_between:1,20',
           ])->validate();
        }

        $studentup = Student::find($student);
        $studentup->name = mb_convert_case($request->nombre, MB_CASE_TITLE,"UTF-8");
        $studentup->f_surname = mb_convert_case($request->apellido_paterno, MB_CASE_TITLE,"UTF-8");
        $studentup->s_surname =  mb_convert_case($request->apellido_materno, MB_CASE_TITLE,"UTF-8");
        $studentup->phone = $request->telefono;
        $studentup->school_email = $request->email_escolar;
        $studentup->personal_email = $request->email_personal;
        if(isset($request->cv)) {
            $file2 = $request->file('cv')->store('cv');
            $studentup->cv = $file2;
        }
        $studentup->status = mb_convert_case($request->estatus, MB_CASE_TITLE,"UTF-8");
        if(isset($request->imagen)) {
            $file = $request->file('imagen')->store('student');
            $studentup->image = $file;
        }
        $studentup->save();

        $programs = ProgramStudent::select('program_id')->where([['student_id',$student]])->get();

        foreach ($programs as $valor) {
            $programs2[] = $valor->program_id;
        }

        if (empty($programs2)) {

        }else{
            $collection = collect($programs2);
            $diff = $collection->diff($data['programa']);
            $diff->all();

            foreach ($diff as $valor2) {
                ProgramStudent::where([['student_id',$student],['program_id',$valor2]])->delete();
            }
        }

        foreach ($insert as $key) {
            
            $count = ProgramStudent::where([['student_id',$student],['program_id',$key['programa']]])->count();

            if ($count=='1') {
                # code...
            }else{
                $programstudentnew = new ProgramStudent;
                $programstudentnew->program_id = $key['programa'];
                $programstudentnew->student_id = $student;
                $programstudentnew->save();
            }
        }

        return redirect()->action('Root\StudentController@index')->with('status', 'Estudiante editado exitosamente');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $student = decrypt($id);

        $studentedelete = Student::find($student);
        $studentedelete->delete();

        return redirect()->action('Root\StudentController@index')->with('status','Estudiante eliminado exitosamente');
    }
}

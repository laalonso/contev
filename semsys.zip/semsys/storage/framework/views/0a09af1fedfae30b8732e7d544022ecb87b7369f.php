

<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-12">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Perfil</li>
          </ol>
        </nav>
            <div class="card">
                <div class="card-header">  <?php echo e(__('DATOS INSTITUCIONALES SOLO PUEDEN SER EDITADOS SOLO POR EL ADMINISTRADOR DE LA UNIVERSIDAD')); ?></div>
                <div class="card-body">

                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session('status')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div id="img-estudiante">
                        <img class="img-fluid" src="<?php echo e(asset('/img/'.Auth::User()->image)); ?>">
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <strong>UNIDAD ACADÉMICA:</strong> <span id="uni-estudiante" class="d-none"><?php echo e(Auth::User()->student()->first()->university_id); ?></span>
                         </li>
                         <li class="list-group-item">
                            <strong>MODALIDAD:</strong> <span id="modalidad-estudiante" class="d-none"></span>
                         </li>
                         <li class="list-group-item">
                            <strong>CARRERA:</strong> <span id="carrera-estudiante" class="d-none"><?php echo e(Auth::User()->student()->first()->program_id); ?></span>
                         </li>
                         <li class="list-group-item">
                            <strong>MATRÍCULA:</strong> <?php echo e(Auth::User()->student()->first()->enrollment); ?>

                         </li>
                        <li class="list-group-item">
                            <strong>NOMBRE:</strong> <?php echo e(Auth::User()->name); ?> <?php echo e(Auth::User()->f_surname); ?> <?php echo e(Auth::User()->s_surname); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>TELEFONO:</strong> <?php echo e(Auth::User()->phone); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>CORREO INSTITUCIONAL:</strong> <?php echo e(Auth::User()->email); ?>

                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>


    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">  <?php echo e(__('DATOS PERSONALES')); ?></div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <strong>EMAIL PERSONAL:</strong> <?php echo e(Auth::User()->student()->first()->personal_email); ?>

                         </li>
                         <li class="list-group-item">
                            <strong>TEL. PERSONAL:</strong> <?php echo e(Auth::User()->student()->first()->personal_tel); ?>

                         </li>
                         <li class="list-group-item">
                            <strong>CURRICULUM:</strong>
                         </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        var id_universidad=$("#uni-estudiante").text();

        $.getJSON('https://semsys.sev.gob.mx/ApiGlobal/ApiGeneral/contec/GetIdEscuelas/'+id_universidad, function(data){
                $("#uni-estudiante").html(data[0].Nombre);
                $("#modalidad-estudiante").text(data[0].Modalidad);
                $("#uni-estudiante").removeClass("d-none");
                $("#uni-estudiante").addClass("d-line");
                var id_modalidad=data[0].Modalidad;

                $.getJSON('https://semsys.sev.gob.mx/ApiGlobal/ApiGeneral/contec/GetIdModalidad/'+id_modalidad, function(data){
                    $("#modalidad-estudiante").text(data[0].Nombre);
                    $("#modalidad-estudiante").removeClass("d-none");
                    $("#modalidad-estudiante").addClass("d-line");
                });
            });
        var carrera_id=$("#carrera-estudiante").text();
        $.getJSON('https://semsys.sev.gob.mx/ApiGlobal/ApiGeneral/contec/GetIdOferta/'+carrera_id, function(data){
                    $("#carrera-estudiante").text(data[0].Nombre_Carrera);
                    $("#carrera-estudiante").removeClass("d-none");
                    $("#carrera-estudiante").addClass("d-line");
                });


        $(".show-modal").on('click',function () {
            var ido = $(this).attr('id');
            $("#content_archivo").html('<embed src="/img/'+ido+'") }}" type="application/pdf" width="100%" height="500px" />');
            $('#showm').modal('show');
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semsys_01092020\semsys\resources\views/root/university/evaluation/index.blade.php ENDPATH**/ ?>
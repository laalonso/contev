<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/home">Home</a></li>
                <li class="breadcrumb-item"><a href="/root/university/all">Universidades</a></li>
                <li class="breadcrumb-item active" aria-current="page">Asignar Encargado</li>
              </ol>
            </nav>

            <div class="card">
                <div id="uni-encargado" class="card-header"><?php echo e(__('Asiganar Encargado de ')); ?></div>
                <input type="text" name="buscar" id="buscar-encargado" placeholder="BUSCAR">
                <div class="card-body">
                    
                    <input type="hidden" id="id_universidad" name="id_universidad" value="<?php echo e($id_universidad); ?>">
                    <table class="table">
                        <tr>
                            <th>#</th>
                            <th>NOMBRE COMPLETO</th>
                            <th>EMAIL</th>
                            <th>TELÉFONO</th>
                            <th>ASIGNAR</th>
                        </tr>
                        <tbody id="tabla-encargados">
<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($usuario->name); ?> <?php echo e($usuario->f_surname); ?> <?php echo e($usuario->s_surnamer); ?></td>
                                <td><?php echo e($usuario->email); ?></td>
                                <td><?php echo e($usuario->phone); ?></td>
                                <td><a class="btn btn-primary" href="/root/university/encargado/<?php echo e($usuario->id); ?>/<?php echo e($id_universidad); ?>" role="button">Asignar</a></td>
                            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        var id_universidad=$("#id_universidad").val();

         $.getJSON('https://semsys.sev.gob.mx/ApiGlobal/ApiGeneral/contec/GetIdSubsistema/'+id_universidad, function(data){
                var titulo=$("#uni-encargado").text();

                $("#uni-encargado").text(titulo+" "+data[0].Nombre);

            });

         $("#buscar-encargado").keyup(function(){
                _this = this;
                 // Show only matching TR, hide rest of them
                 $.each($("#tabla-encargados tr"), function() {
                 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
                 $(this).hide();
                 else
                 $(this).show();
                 });
                 });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semsys_01092020\semsys\resources\views/root/university/create.blade.php ENDPATH**/ ?>
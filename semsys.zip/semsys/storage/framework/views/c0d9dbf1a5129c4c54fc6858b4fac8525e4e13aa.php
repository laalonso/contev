<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/home">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Estudiantes</li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-header"><?php echo e(__('ESTUDIANTES')); ?></div>
                <a href="<?php echo e(url('/university/students/create')); ?>" class="btn btn-success">Añadir</a>
                <div class="card-body table-responsive">
                    
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session('status')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Matrícula</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Carrera</th>
                                <th scope="col">Estatus</th>
                                <th scope="col">Teléfono</th>
                                <th scope="col">Email Escolar</th>
                                <th scope="col">CV</th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody id="tabla-estudiantes">
<?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="f<?php echo e($loop->index+1); ?>">
                                <th scope="row"><?php echo e($loop->index+1); ?></th>
                                <td><?php echo e($estudiante->enrollment); ?></td>
                                <td><?php echo e($estudiante->user->name); ?> <?php echo e($estudiante->user->f_surname); ?> <?php echo e($estudiante->user->s_surname); ?></td>
                                <td><div class="carrera-estudiante d-none"><?php echo e($estudiante->program_id); ?></div></td>
                                <td><?php echo e($estudiante->status); ?></td>
                                <td><?php echo e($estudiante->user->phone); ?></td>
                                <td><?php echo e($estudiante->user->email); ?></td>
                                
                                <td> 
                                    <button type="button" class="btn btn-primary show-modal" id="">
                                        Ver
                                    </button>
                                </td>
                                <td><br>                   
                              
                                </td>
                                <td>
                                    <form action=" " method="GET">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="btn btn-primary">Evaluaciones</button>
                                    </form>
                                </td>
                                <td>
                                    <a href="students/'.encrypt($info->id).'/edit') }}" class="btn btn-warning" role="button">Editar</a>
                                </td>
                                <td>
                                    <form action="" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                </td>                        
                            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

  
<!-- Modal -->
<div class="modal fade" id="showm" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Curriculum Vitae</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <div class="row">
            <div class="col-md-12" align="center" id="content_cv">

            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
    </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {

        $("#tabla-estudiantes tr").each(function(){
            var fila=$(this).attr("id");
            var carrera_id=$(this).find(".carrera-estudiante").text();

             $.getJSON('https://semsys.sev.gob.mx/ApiGlobal/ApiGeneral/contec/GetIdOferta/'+carrera_id, function(data){

                    $("#"+fila).find(".carrera-estudiante").html(data[0].Nombre_Carrera);
                   $("#"+fila).find(".carrera-estudiante").removeClass("d-none");
                   $("#"+fila).find(".carrera-estudiante").addClass("d-block");
                });
          });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semsys_01092020\semsys\resources\views/root/university/student/index.blade.php ENDPATH**/ ?>
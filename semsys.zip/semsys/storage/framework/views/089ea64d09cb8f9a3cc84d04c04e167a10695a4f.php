<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/home">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Crear Servicio</li>
                </ol>
            </nav>

            <h2 class="d-none" id="universidad-nombre"><?php echo e($id_universidad); ?></h2>
            <div class="card">
                <div class="card-header"><?php echo e(__('Crear Servicio')); ?></div>

                <div class="card-body">
                    <form action="/university/services" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="nombre">Nombre</label>
                                <input type="text" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" id="nombre" name="nombre" maxlength="60" value="<?php echo e(old('nombre')); ?>" placeholder="Ingrese un nombre" required autofocus>
                                <?php if($errors->has('nombre')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="tipo">Tipo</label>
                                <input type="text" class="form-control<?php echo e($errors->has('tipo') ? ' is-invalid' : ''); ?>" id="tipo" name="tipo" maxlength="45" value="<?php echo e(old('tipo')); ?>" placeholder="Ingrese un tipo" required autofocus>
                                <?php if($errors->has('tipo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tipo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="descripcion">Descripción</label>
                                <textarea name="descripcion" class="form-control<?php echo e($errors->has('descripcion') ? ' is-invalid' : ''); ?>" id="descripcion" placeholder="Ingrese una descripción del servicio" rows="5" maxlength="255" autofocus required><?php echo e(old('descripcion')); ?></textarea>
                                <?php if($errors->has('descripcion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>  
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12" align="right">
                                <button class="btn btn-success">Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        var id_universidad=$("#universidad-nombre").text();

         $.getJSON('https://semsys.sev.gob.mx/ApiGlobal/ApiGeneral/contec/GetIdSubsistema/'+id_universidad, function(data){
                $("#universidad-nombre").html(data[0].Nombre);
                $("#universidad-nombre").removeClass("d-none");
                $("#universidad-nombre").addClass("d-block");
            });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semsys_01092020\semsys\resources\views/root/university/serviceuni/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/home">Home</a></li>
                    <li class="breadcrumb-item"><a href="/university/services">Servicios</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Editar Servicio</li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-header"><?php echo e(__('Editar Servicio')); ?></div>

                <div class="card-body">
                        <form action="<?php echo e(url('/university/services/'.encrypt($info->id).'')); ?>" method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="nombre">Nombre</label>
                                <input type="text" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" id="nombre" name="nombre" maxlength="60" value="<?php echo e($info->name); ?>" placeholder="Ingrese un nombre" required autofocus>
                                <?php if($errors->has('nombre')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="tipo">Tipo</label>
                                <input type="text" class="form-control<?php echo e($errors->has('tipo') ? ' is-invalid' : ''); ?>" id="tipo" name="tipo" maxlength="45" value="<?php echo e($info->type); ?>" placeholder="Ingrese un tipo" required autofocus>
                                <?php if($errors->has('tipo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tipo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="descripcion">Descripción</label>
                                <textarea name="descripcion" class="form-control<?php echo e($errors->has('descripcion') ? ' is-invalid' : ''); ?>" id="descripcion" placeholder="Ingrese una descripción del servicio" rows="5" maxlength="255" autofocus required><?php echo e($info->description); ?></textarea>
                                <?php if($errors->has('descripcion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12" align="right">
                                <button class="btn btn-success">Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        $('.universidad').select2({
            language: {
            noResults: function() {
                return "No hay resultado";
            },
            searching: function() {
                return "Buscando..";
            }
            },
        }).width("100%");
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semsys_01092020\semsys\resources\views/root/university/serviceuni/edit.blade.php ENDPATH**/ ?>
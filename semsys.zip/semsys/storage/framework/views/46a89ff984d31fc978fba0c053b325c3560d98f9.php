<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/home">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Agregar evaluación</li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-header">
                    <div class="float-left"><?php echo e(__('CREAR EVALUACIÓN O CERTIFICACIÓN')); ?></div>
                    <div class="float-right">
                    </div>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/estudiantes')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->has('student')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('student')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <div class="form-group">
                        <div class="row">
                            <div class="form-group col-md-12 col-sm-12">
                                <label for="evaluacion">Nombre de la evaluación</label>
                                <input type="text" name="evaluacion" class="form-control<?php echo e($errors->has('evaluacion') ? ' is-invalid' : ''); ?>" id="evaluacion" maxlength="100" placeholder="Ingrese un nombre" value="<?php echo e(old('evaluacion')); ?>" required autofocus>
                                <?php if($errors->has('evaluacion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('evaluacion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12 col-sm-12">
                                <label for="descripcion">Descripción de la evaluación</label>
                                <textarea class="form-control" id="descripcion" name="descripcion" rows="3"></textarea>
                                <?php if($errors->has('descripcion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12 col-sm-12">
                                <label for="archivo_evaluacion">Archivo comprobante o certificado</label>
                                <input type="file" class="form-control<?php echo e($errors->has('archivo_evaluacion') ? ' is-invalid' : ''); ?>" id="archivo_evaluacion" name="archivo_evaluacion" accept="application/pdf" value="<?php echo e(old('archivo_evaluacion')); ?>" required autofocus>
                                <?php if($errors->has('archivo_evaluacion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('archivo_evaluacion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-12 col-sm-12" align="right">
                                <button type="submit"  class="btn btn-success">Guardar</button>
                            </div>
                            </div>
                        </div>
                    </form> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semsys_01092020\semsys\resources\views/root/university/evaluation/create.blade.php ENDPATH**/ ?>
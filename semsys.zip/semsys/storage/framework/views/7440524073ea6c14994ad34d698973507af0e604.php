

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div id="uni-encargado" class="card-header"><?php echo e(__('LISTA DE ENCARGADOS ')); ?></div>
                <input type="text" name="buscar" id="buscar-encargado" placeholder="BUSCAR">
                <div class="card-body">
                    
                    <table class="table">
                        <tr>
                            <th>#</th>
                            <th>NOMBRE COMPLETO</th>
                            <th>EMAIL</th>
                            <th>TELÉFONO</th>
                            <th>UNIVERSIDAD</th>
                        </tr>
                        <tbody id="tabla-encargados">
<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><div id="indice"><?php echo e($loop->index+1); ?></div></td>
                                <td><?php echo e($usuario->name); ?> <?php echo e($usuario->f_surname); ?> <?php echo e($usuario->s_surnamer); ?></td>
                                <td><?php echo e($usuario->email); ?></td>
                                <td><?php echo e($usuario->phone); ?></td>
                                <td>
                                    <div id="university_id">
<?php
                                        if(isset($usuario->university()->first()->university_id)){
                                           echo  $usuario->university()->first()->university_id;
                                        }else{
                                            echo "Sin asignar";
                                        }
?>
                                    </div>
                                </td>
                            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(document).ready(function(){

        $.each($("#tabla-encargados tr"), function(index) {
            var university_id=$(this).find("#university_id").text();
            var id="university_id"+index;
            $(this).find("#university_id").attr('id',id);

            if(!isNaN(university_id)){
                $.getJSON('https://semsys.sev.gob.mx/ApiGlobal/ApiGeneral/contec/GetIdSubsistema/'+university_id, function(data){
                        $("#tabla-encargados tr").find("#"+id).html(data[0].Nombre);
                 });   
            }else{
                $(this).attr("class","table-danger");
            }

        });
         $("#buscar-encargado").keyup(function(){
                _this = this;
                 // Show only matching TR, hide rest of them
                 $.each($("#tabla-encargados tr"), function() {
                 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
                 $(this).hide();
                 else
                 $(this).show();
                 });
                 });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semsys_01092020\semsys\resources\views/root/encargados/index.blade.php ENDPATH**/ ?>
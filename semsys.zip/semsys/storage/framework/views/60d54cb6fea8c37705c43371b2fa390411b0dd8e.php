<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/home">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Crear Proyecto</li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-header"><?php echo e(__('Crear Proyecto')); ?></div>

                <div class="card-body">
                    <form action="<?php echo e(url('/university/projects')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="nombre">Nombre</label>
                                <input type="text" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" id="nombre" name="nombre" maxlength="60" value="<?php echo e(old('nombre')); ?>" placeholder="Ingrese un nombre" required autofocus>
                                <?php if($errors->has('nombre')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="progreso">Progreso</label>
                                <select class="form-control" name="progreso" id="progreso" autofocus required>
                                    <option value="" selected>Elija una opción</option>
                                    <option value="Pendiente">Pendiente</option>
                                    <option value="Desarrollo">En Desarrollo</option>
                                    <option value="Inversión">Listo para Inversión</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="palabras_clave">Palabras Clave</label>
                                <input type="text" class="form-control<?php echo e($errors->has('palabras_clave') ? ' is-invalid' : ''); ?>" id="palabras_clave" name="palabras_clave" maxlength="45" value="<?php echo e(old('palabras_clave')); ?>" placeholder="Ingrese palabras clave" required autofocus>
                                <?php if($errors->has('palabras_clave')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('palabras_clave')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="descripcion">Descripción</label>
                                <textarea name="descripcion" class="form-control<?php echo e($errors->has('descripcion') ? ' is-invalid' : ''); ?>" id="descripcion" placeholder="Ingrese una descripción" rows="5" maxlength="255" autofocus required><?php echo e(old('descripcion')); ?></textarea>
                                <?php if($errors->has('descripcion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12" align="right">
                                <button class="btn btn-success">Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semsys_01092020\semsys\resources\views/root/university/project/create.blade.php ENDPATH**/ ?>
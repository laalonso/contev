<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes(['register' => false]);

Route::group(['middleware' => ['auth']], function () {

    Route::get('/home', 'HomeController@index')->name('home');
//-------------------------Encargado de universidad-------------------------
    Route::resource('university/services','Root\UniversityServiceController')->middleware('encargado');

    Route::resource('university/projects','Root\ProjectUniversityController')->middleware('encargado');
            Route::get('university/projects/addStudent/{projet_id}','Root\ProjectUniversityController@addStudent')->middleware('encargado');
            Route::get('university/projects/addStudent/save/{project_id}/{student_id}','Root\ProjectUniversityController@saveStudentProject')->middleware('encargado');
            Route::get('university/projects/details/{project_id}','Root\ProjectUniversityController@detalles')->middleware('encargado');
    Route::resource('university/students','Root\StudentController')->middleware('encargado');
//---------------------Rutas de los estudiantes--------------------------
    Route::resource('estudiantes','Root\StudentEvaluationController')->middleware('estudiante');
        Route::get('estudiantes/evaluaciones/lista','Root\StudentEvaluationController@listaEvaluaciones')->middleware('estudiante');

    //////////////////////////// ROOT ///////////////////////////
    Route::group(['middleware' => ['root']], function () {
        Route::prefix('root')->group(function () {

            Route::prefix('user')->group(function () {
                Route::resources([
                    'all' => 'Root\UserController',
                ]);
            });

            Route::prefix('rol')->group(function () {
                Route::resources([
                    'all' => 'Root\RoleController',
                ]);
            });

            Route::prefix('university')->group(function () {
                Route::resources([
                    'all' => 'Root\UniversityController',
                    'systems' => 'Root\SystemController',
                ]);
              //  Route::get('/studentevaluations/create2/{student}', 'Root\StudentEvaluationController@create');
//Ruta para la asignación de encargado de la univesidad
                Route::get('/encargado/{id_universidad}','Root\UniversityController@asignarEncargado');
//Ruta para guardar el encargado de la universidad
                Route::get('/encargado/{id_user}/{id_universidad}/','Root\UniversityController@guardarEncargado');
//Ruta para mostrar la lista de encargados de lasuniversidades
                Route::get('/encargados','Root\UniversityController@listaEncargados');
            });
            
        });
    });

});